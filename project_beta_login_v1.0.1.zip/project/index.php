<?php

echo '<a href="logout.php">logout</a>';

?>
